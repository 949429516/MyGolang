package mylogger

import (
	"fmt"
	"os"
	"path"
	"path/filepath"
	"time"
)

func NewFileLog(levelStr, fp, fn string, maxFileSize int64) *FileLogger {
	level, err := parseLogLevel(levelStr)
	if err != nil {
		panic(err)
	}
	fullFileName := filepath.Join(fp, fn)
	fileobj, err := os.OpenFile(fullFileName, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		panic(err)
	}
	fileerrobj, err := os.OpenFile(fullFileName+".err", os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		panic(err)
	}
	return &FileLogger{
		Level:       level,
		filePath:    fp,
		fileName:    fn,
		maxFileSize: maxFileSize,
		fileObj:     fileobj,
		errfileObj:  fileerrobj,
	}
}
func (l *FileLogger) checkSize(file *os.File) bool {
	fileObj, err := file.Stat()
	if err != nil {
		return false
	}
	return fileObj.Size() >= l.maxFileSize
}
func (l *FileLogger) splitFile(file *os.File) (*os.File, error) {
	nowStr := time.Now().Format("20060102150405000000")
	logName := path.Join(l.filePath, file.Name())
	newLogName := fmt.Sprintf("%s.bak%s", logName, nowStr)
	os.Rename(logName, newLogName)
	file.Close()
	fileobj, err := os.OpenFile(logName, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		panic(err)
	}
	return fileobj, nil
}
func (l *FileLogger) filelog(lv LogLevel, format string, a ...interface{}) {
	if lv >= l.Level {
		msg := fmt.Sprintf(format, a...)
		now := time.Now()
		funcName, fileName, lineNo := getInfo(3)
		if l.checkSize(l.fileObj) {
			newFile, err := l.splitFile(l.fileObj)
			if err != nil {
				return
			}
			l.fileObj = newFile
		}
		fmt.Fprintf(l.fileObj, "[%s] [%s] [%s %s %d] %s\n", now.Format("2006-01-02 15:04:05"), getLogString(lv), funcName, fileName, lineNo, msg)
		if lv >= ERROR {
			if l.checkSize(l.errfileObj) {
				newFile, err := l.splitFile(l.errfileObj)
				if err != nil {
					return
				}
				l.errfileObj = newFile
			}
			fmt.Fprintf(l.errfileObj, "[%s] [%s] [%s %s %d] %s\n", now.Format("2006-01-02 15:04:05"), getLogString(lv), funcName, fileName, lineNo, msg)
		}
	}
}
func (l *FileLogger) Debug(format string, a ...interface{}) {
	l.filelog(DEBUG, format, a...)
}
func (l *FileLogger) Info(format string, a ...interface{}) {
	l.filelog(INFO, format, a...)
}
func (l *FileLogger) Trace(format string, a ...interface{}) {
	l.filelog(TRACE, format, a...)
}
func (l *FileLogger) Warning(format string, a ...interface{}) {
	l.filelog(WARNING, format, a...)
}
func (l *FileLogger) Error(format string, a ...interface{}) {
	l.filelog(ERROR, format, a...)
}
func (l *FileLogger) Fatal(format string, a ...interface{}) {
	l.filelog(FATAL, format, a...)
}
